import { useState } from "react";
import { ArrowRight, Check, GraduationCap, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export type UserRole = "student" | "recruiter" | "officer";

type AuthMode = "login" | "signup" | "forgot";

const roleOptions: { id: UserRole; title: string; description: string }[] = [
  { id: "student", title: "Student", description: "Prepare for placements and discover opportunities." },
  { id: "recruiter", title: "Recruiter", description: "Find and evaluate suitable candidates." },
  { id: "officer", title: "Placement Officer", description: "Manage students, drives, training and placement analytics." },
];

function routeForRole(role: UserRole) {
  return role === "student" ? "/student/home" : role === "recruiter" ? "/recruiter/dashboard" : "/tpo/dashboard";
}

function saveSession(role: UserRole) {
  localStorage.setItem("place-twin-session", JSON.stringify({ role, signedInAt: new Date().toISOString() }));
}

function AuthBrand() {
  return <section className="auth-brand-panel"><div className="auth-brand"><img src="/place-twin-logo.png" alt="" /><strong>PLACE TWIN</strong></div><span className="auth-tagline">Don't Wait for Placement.<br /><b>Simulate It.</b></span><h1>Your Placement Journey Starts Here</h1><p>Assess your skills, explore opportunities, and prepare for your next placement.</p><div className="auth-journey" aria-label="Placement journey"><span>Profile</span><ArrowRight size={14} /><span>Skills</span><ArrowRight size={14} /><span>Match</span><ArrowRight size={14} /><span>Prepare</span><ArrowRight size={14} /><span>Simulate</span><ArrowRight size={14} /><span>Placement</span></div><div className="auth-note"><ShieldCheck size={16} /> Evidence-led placement preparation</div></section>;
}

function Field({ label, type = "text", placeholder, required = true }: { label: string; type?: string; placeholder: string; required?: boolean }) { return <label className="auth-field"><span>{label}{required && <em>*</em>}</span><input type={type} placeholder={placeholder} required={required} /></label>; }

function RoleSelector({ role, setRole }: { role: UserRole; setRole: (role: UserRole) => void }) {
  return <div className="role-selector"><span className="auth-label">Choose your role</span><div className="role-option-grid">{roleOptions.map((item) => <button type="button" key={item.id} className={`role-option ${role === item.id ? "selected" : ""}`} onClick={() => setRole(item.id)}><span className="role-radio">{role === item.id && <Check size={11} />}</span><strong>{item.title}</strong><small>{item.description}</small></button>)}</div></div>;
}

function StudentProfile({ onDone }: { onDone: () => void }) {
  return <div className="auth-card profile-onboarding"><div className="auth-card-kicker"><GraduationCap size={15} /> Student first-time setup</div><h2>Let's build your placement profile.</h2><p className="auth-card-subtitle">A complete profile helps PLACE TWIN match you with the right opportunities.</p><div className="auth-form-grid"><Field label="Name" placeholder="Vishali Sharma" /><Field label="College" placeholder="Northstar University" /><Field label="Department" placeholder="Computer Science & Engineering" /><Field label="Year" placeholder="Final year" /><Field label="CGPA" placeholder="8.4" /><Field label="Target Role" placeholder="Software Developer" /></div><label className="auth-field"><span>Skills</span><input placeholder="Java, SQL, DSA, OOP" /></label><label className="auth-field"><span>Projects</span><input placeholder="E-commerce API project" /></label><label className="auth-field"><span>Certifications</span><input placeholder="Optional" /></label><label className="upload-field"><span>Resume Upload</span><input type="file" /></label><button className="auth-primary" onClick={onDone}>Build My Profile <ArrowRight size={15} /></button></div>;
}

function AuthForm({ mode, setMode, role, setRole, onSignedIn }: { mode: AuthMode; setMode: (mode: AuthMode) => void; role: UserRole; setRole: (role: UserRole) => void; onSignedIn: (role: UserRole, firstTime?: boolean) => void }) {
  const [loading, setLoading] = useState(false);
  const isSignup = mode === "signup";
  const isForgot = mode === "forgot";
  function submit(event: React.FormEvent<HTMLFormElement>) { event.preventDefault(); const passwordFields = event.currentTarget.querySelectorAll<HTMLInputElement>('input[type="password"]'); if (isSignup && passwordFields[0]?.value !== passwordFields[1]?.value) { toast.error("Passwords do not match", { description: "Please confirm the same password before creating your account." }); return; } setLoading(true); window.setTimeout(() => { setLoading(false); if (isForgot) { toast("Reset link requested", { description: "A demo reset link would be sent to your email." }); return; } saveSession(role); onSignedIn(role, isSignup && role === "student"); }, 250); }
  return <div className="auth-card"><div className="auth-card-kicker">{isForgot ? "Account access" : "Welcome to PLACE TWIN"}</div><h2>{isForgot ? "Forgot your password?" : isSignup ? "Create your PLACE TWIN account" : "Welcome back"}</h2><p className="auth-card-subtitle">{isForgot ? "Enter your email and we’ll help you get back in." : isSignup ? "Choose your role and start your placement journey." : "Sign in to continue to PLACE TWIN."}</p><form onSubmit={submit}>{isSignup && <Field label="Full Name" placeholder="Vishali Sharma" />}<Field label="Email Address" type="email" placeholder="you@college.edu" />{!isForgot && <Field label="Password" type="password" placeholder="••••••••" />}{isSignup && <><Field label="Confirm Password" type="password" placeholder="••••••••" /><Field label="College / Institution" placeholder="Northstar University" /><RoleSelector role={role} setRole={setRole} /></>}{!isSignup && !isForgot && <div className="auth-meta"><label className="remember"><input type="checkbox" /> Remember me</label><button type="button" onClick={() => setMode("forgot")}>Forgot Password?</button></div>}<button className="auth-primary" type="submit" disabled={loading}>{loading ? "Please wait…" : isForgot ? "Send Reset Link" : isSignup ? "Create Account" : "Login"} {!isForgot && <ArrowRight size={15} />}</button></form>{!isForgot && <><div className="auth-divider"><span>OR</span></div><button className="google-button" onClick={() => { saveSession(role); onSignedIn(role, false); }}>Continue with Google</button></>}{isForgot ? <div className="auth-switch">Remember your password? <button onClick={() => setMode("login")}>Login</button></div> : <div className="auth-switch">{isSignup ? "Already have an account?" : "Don't have an account?"} <button onClick={() => setMode(isSignup ? "login" : "signup")}>{isSignup ? "Login" : "Create Account"}</button></div>}</div>;
}

export default function AuthPage({ initialMode = "login" }: { initialMode?: AuthMode }) {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [role, setRole] = useState<UserRole>("student");
  const [firstTime, setFirstTime] = useState(false);
  const finishAuth = (selectedRole: UserRole, needsProfile = false) => { if (needsProfile) { setFirstTime(true); return; } setLocation(routeForRole(selectedRole)); };
  if (firstTime) return <div className="auth-page"><AuthBrand /><main className="auth-form-area"><StudentProfile onDone={() => setLocation("/student/home")} /></main></div>;
  return <div className="auth-page"><AuthBrand /><main className="auth-form-area"><AuthForm mode={mode} setMode={setMode} role={role} setRole={setRole} onSignedIn={finishAuth} /></main></div>;
}
