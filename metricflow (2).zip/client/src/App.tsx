import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AuthPage from "./pages/Auth";
import Home from "./pages/Home";

function LoginRoute() { return <AuthPage initialMode="login" />; }
function SignupRoute() { return <AuthPage initialMode="signup" />; }
function ForgotPasswordRoute() { return <AuthPage initialMode="forgot" />; }

function ProtectedHome({ role }: { role: "student" | "recruiter" | "officer" }) {
  const [, setLocation] = useLocation();
  const raw = typeof window !== "undefined" ? localStorage.getItem("place-twin-session") : null;
  if (!raw) {
    setLocation("/login");
    return null;
  }
  let sessionRole = role;
  try {
    const session = JSON.parse(raw) as { role?: "student" | "recruiter" | "officer" };
    if (session.role) sessionRole = session.role;
  } catch {
    localStorage.removeItem("place-twin-session");
    setLocation("/login");
    return null;
  }
  if (sessionRole !== role) {
    setLocation(sessionRole === "recruiter" ? "/recruiter/dashboard" : sessionRole === "officer" ? "/tpo/dashboard" : "/student/home");
    return null;
  }
  const initialScreen = sessionRole === "recruiter" ? "Recruiter" : sessionRole === "officer" ? "TPO" : "Home";
  return <Home initialScreen={initialScreen} />;
}

function Router() {
  return <Switch>
    <Route path="/" component={LoginRoute} />
    <Route path="/login" component={LoginRoute} />
    <Route path="/signup" component={SignupRoute} />
    <Route path="/forgot-password" component={ForgotPasswordRoute} />
    <Route path="/student/home"><ProtectedHome role="student" /></Route>
    <Route path="/recruiter/dashboard"><ProtectedHome role="recruiter" /></Route>
    <Route path="/tpo/dashboard"><ProtectedHome role="officer" /></Route>
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
