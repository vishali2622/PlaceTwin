# PLACE TWIN

**Don't Wait for Placement. Simulate It.**

PLACE TWIN is a professional university placement and recruitment intelligence dashboard for exploring placement readiness, skill gaps, recruitment pipelines, placement simulations, and What-If analysis.

- `pnpm dev`: development server; honors `PORT` (default 3000).
- `pnpm build` / `pnpm start`: build and serve `dist/index.js` and `dist/public/`.
- `pnpm check` / `pnpm test`: types and application tests.
- `pnpm dev:static` / `pnpm build:static`: static preview and production build for the dashboard.

Simulation results are estimates and decision-support signals; they do not guarantee recruitment success.
