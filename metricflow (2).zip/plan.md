# PLACE TWIN — Multi-screen Student Placement Platform Plan

## Product scope

PLACE TWIN is a light, professional university placement intelligence platform for students, recruiters, and placement officers. The current dashboard design remains unchanged. This increment adds the actual authentication entry flow and connects it to role-specific dashboard routes.

## Authentication and routing

- `/`, `/login`: Login page with PLACE TWIN branding, simple placement journey visual, email/password, remember-me, forgot-password, login, Google continuation, and signup link.
- `/signup`: Signup form with full name, email, password, confirmation, college/institution, and clear Student / Recruiter / Placement Officer role cards.
- `/forgot-password`: Email reset request with prototype confirmation toast.
- Student signup/login: stores a lightweight local demo session. First-time students see “Let’s build your placement profile” with education, skills, projects, certifications, target role, and resume upload fields before entering `/student/home`.
- Role redirects: Student → `/student/home`, Recruiter → `/recruiter/dashboard`, Placement Officer → `/tpo/dashboard`.
- Protected routes: role dashboard routes redirect to `/login` when the local prototype session is missing. Logout clears the session and returns to `/login`.
- Prototype transparency: this is demo authentication using local storage/session state, structured so a real backend can replace the persistence layer later.

## Dashboard preservation

The existing PLACE TWIN light theme, warm off-white background, white cards, deep navy primary, muted green success, muted amber warning, typography, journey-centered Student Home, and role-specific application screens remain in place. No dark mode, gradients, neon, glow, AI graphics, or generic business analytics layout.

## Main screens

- Student: Home, My Journey, My Skills, Companies, Company Details, Assessments, Placement Digital Twin, What-If, Preparation, Applications, Results, Profile/Settings.
- Recruiter: Recruiter Panel with applicants, verified candidates, candidate evidence, shortlist action, and role-specific tab navigation.
- Placement Officer/TPO: College Placement Overview, skill/priority counts, current drive bottleneck, intervention recommendation, and simulation/training actions.

## Verification

- Run `pnpm check` and `pnpm build:static`.
- Verify route manifest and static asset paths.
- Verify login, signup, forgot-password, role selection, first-time student setup, logout, and role route behavior in the browser.
- Confirm the light styling remains intact and save a clean canonical checkpoint.
