# PLACE TWIN Design Brief — Placement Command Center

## Theme Name

**Quiet Momentum** — a calm academic workspace that helps a student understand their next placement step without feeling like an operations console.

## Design movement

Personal university product design: warm paper-like page background, white study-card surfaces, clear line-based journey visuals, and restrained status colors.

## Core principles

- Journey before statistics.
- Personal before institutional.
- Action before explanation.
- Every scenario is labelled as a scenario and never promises selection.
- Use whitespace and simple line icons to keep the page calm.

## Color philosophy

- Background: warm off-white `#F7F7F3`.
- Surface: white `#FFFFFF`.
- Text: deep navy `#18334A`.
- Muted: slate `#71808A`.
- Border: warm grey `#E4E6E2`.
- Primary: deep navy `#18334A`.
- Success: muted green `#6E9A7A` with pale green `#EAF2EC`.
- Warning: muted amber `#B88A4A` with pale amber `#FBF2E2`.
- Upcoming: neutral grey `#B9C1C4` with pale grey `#F1F2F0`.

## Layout paradigm

Slim fixed sidebar. Main content starts with a personal greeting, then a large central “Your Placement Journey” panel. The first viewport hierarchy is: journey, next best action, readiness snapshot, What-If preview, upcoming opportunity. Skill evidence, simulation preview, and personal activity continue below.

## Signature elements

- Paired PLACE TWIN mark using navy and muted green.
- Eight journey circles connected by one clean line.
- Current stage in solid deep navy; completed stages in muted green; upcoming stages in light grey.
- Readiness snapshot uses three small indicators, not KPI tiles.
- Timeline dots for personal activity.

## Interaction philosophy

Clicking a journey stage reveals its detail in the same panel. Clicking a skill reveals its evidence sources. The What-If slider immediately updates estimated readiness values. Buttons show helpful local feedback while keeping the prototype honest.

## Animation

Only fast, subtle transitions on hover, focus, selected stages, and slider updates. No looping motion, glow, gradients, or decorative effects.

## Typography system

Keep DM Sans for body text and Plus Jakarta Sans for headings. Use confident 24–32px headings, compact 11px metadata labels, 13–15px explanatory copy, and 26–34px stage/readiness values.

## Brand essence

PLACE TWIN is a thoughtful placement mentor: evidence-led, transparent, and practical.

## Brand voice

Personal and direct: “Your next best action,” “Your biggest opportunity right now is DSA,” and “Scenario analysis only — not a guaranteed placement outcome.”

## Wordmark/logo

Wordmark: **PLACE TWIN**. Mark: two navy panels linked by a muted-green bridge, representing a student's current profile and future placement path.

## Signature brand color

Deep navy `#18334A`, balanced by muted green `#6E9A7A` and muted amber `#B88A4A`.
